BuildTable('manSupplierSNTbl',[`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`],`manSupplierSNTblArea`);
  var table_1 = DatatableInitialize('manSupplierSNTbl');
  DatatableAppendBody(table_1,[[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ],[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ]],0);