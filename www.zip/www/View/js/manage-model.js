BuildTable('manModelTbl',[`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`],`manModelTblArea`);
  var table_1 = DatatableInitialize('manModelTbl');
  DatatableAppendBody(table_1,[[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ],[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ]],0);