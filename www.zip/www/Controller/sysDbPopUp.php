<?php
function showDbPopUp($text,$isSuccess){
    if ($isSuccess == 1){
        echo "
            <script>
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: 'success',
                text: `$text`,
                showConfirmButton: false,
                timer: 3500
            })
            console.log('$text');
        </script>";
    } else if ($isSuccess == 0){
        echo "
        <script>
        Swal.fire({
            position: 'top-end',
            icon: 'error',
            title: 'failed',
            text: `$text`,
            showConfirmButton: false,
            timer: 3500
        })
        console.log('$text');
    </script>";
    }
    
}

function showDebugPopUp($text){
        echo "
            <script>
            Swal.fire(`<font size='3px'>$text</font>`);
            console.log('$text');
        </script>";
    
}


?>

