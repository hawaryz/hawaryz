




function sidebarMenuNav(obj){
    $('#sidebar').find('.active').removeClass("active");
    $('#top-menu').find('.active').removeClass("active");
    if(typeof obj !== 'undefined')
    {
        if (obj.id == "dashboardBtnId"){
            $("#main-content").load("dashboard.php");
        } else if (obj.id == "stockinBtnId"){
            $("#main-content").load("stock-in.php");
        } else if (obj.id == "stockqcBtnId"){
            $("#main-content").load("stock-qc.php");
        } else if (obj.id == "stockoutBtnId"){
            $("#main-content").load("stock-out.php");
        } else if (obj.id == "deliveryBtnId"){
            $("#main-content").load("stock-delivery.php");
        }
        $(obj).addClass("active");
    }
    else
    {
        $("#main-content").load("dashboard.php");
        $("#dashboardBtnId").addClass("active");
    }
}

function openSetPopupMenu(){
    if ($('#extendedSetMenu').is(':visible')) {
        $('#extendedSetMenu').hide();
    } else {
        $('#extendedSetMenu').show();
    }
}

function topbarMenuNav(obj) {
    $('#sidebar').find('.active').removeClass("active");
    $('#top-menu').find('.active').removeClass("active");
    $(obj).addClass("active");

    if (obj.id == "ManageShippingBtnId") {
        $("#main-content").load("manage-shipping.php");
    } else if (obj.id == "ManageModelBtnId") {
        $("#main-content").load("manage-model.php");
    } else if (obj.id == "ManageWarrantyBtnId") {
        $("#main-content").load("manage-warranty.php");
    } else if (obj.id == "ManageSupplierSNBtnId") {
        $("#main-content").load("manage-supplier-sn.php");
    } else if (obj.id == "ManageSoftwareBtnId") {
        $("#main-content").load("manage-software.php");
    } else if (obj.id == "ManageSupplierBtnId") {
        $("#main-content").load("manage-supplier.php");
        console.log(obj.id);
    }
}