





<script src="../Gateway/Private-Access/js/third-party/jquery-v360.js"></script>
<script src="../Gateway/Private-Access/js/third-party/jquery.dataTables.min.js"></script>
<script src="../Gateway/Private-Access/js/third-party/dataTables.bootstrap4.min.js"></script>
<link rel="stylesheet" href="../Gateway/Private-Access/css/third-party/dataTables.bootstrap4.min.css" />
<link rel="stylesheet" href="../Gateway/Private-Access/css/custom/datatable-inline-edit.css">


<link rel="stylesheet" href="../Gateway/Private-Access/css/third-party/jquery-ui.css">
<!-- <link rel='stylesheet' href='../Gateway/Private-Access/css/third-party/bootstrap.min.css'> -->
<script src="../Gateway/Private-Access/js/third-party/jquery-ui.js"></script>
<link rel="stylesheet" href="../Gateway/Private-Access/css/custom/loader.css">
