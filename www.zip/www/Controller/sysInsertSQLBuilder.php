<?php
function urlToInsertSQL() {
    // THIS FUNCTION USE TO CONVERT URL DATA TO SQL
    // AND THE FINAL RETURN IN SQL (STRING)
    // TO USE THIS FUNCTION FOLLOW BELOW REQUESTED FORMAT
    /*
       * FILEPATH.php?tblname=YourTableName&TABLE_COLUMN_NAME_1=TABLE_COLUMN_VALUE_1&TABLE_COLUMN_NAME_2=TABLE_COLUMN_VALUE_2&TABLE_COLUMN_NAME_3=TABLE_COLUMN_VALUE_3
       * Controller/sysSQLBuilder.php?tblname=models&models_id=1&models_name=hawari&models_itemname=polis
    */
    $dataArrayKey = analyseReqUrlInsertParam();
    $tblName = analyseReqUrlTableName();
    return InsertSQLBuilder($tblName,$dataArrayKey);
}

function InsertSQLBuilder($tableName,$keydata) {
    // InsertSQLBuilder("TABLE_NAME",["COLNAME_1" => "COLVALUE_1", "COLNAME_2" => "COLVALUE_2", "COLNAME_3" => "COLVALUE_2"]);
    // InsertSQLBuilder("models",["models_id" => "XXXX", "models_name" => "XXXXX", "models_itemname" => "XXXXX"]);
    $colcounter = 0;
    $rowcounter = 0;
    $stringSQL = "INSERT INTO `".$tableName."` (";
    foreach($keydata as $key => $value) {
        if ($colcounter != 0) { $stringSQL .= ","; }
        $stringSQL .= "`".$key."`";
        $colcounter++;
    }
    $stringSQL .= ") VALUES (";
    foreach($keydata as $key => $value) {
        if ($rowcounter != 0) { $stringSQL .= ","; }
        $stringSQL .= "'".$value."'";
        $rowcounter++;
    }
    $stringSQL .= ")";
    return $stringSQL;
}

function analyseReqUrlInsertParam() {
    // THIS FUNCTION USE TO GET PARAMETER DATA FROM REQUESTED URL
    // AND CONVERT TO ARRAY KEY DATA
    $url = $_SERVER['REQUEST_URI'];    
    $arrayData = array();
    $getParam = explode("?",$url)[1];
    $getData = explode("&",$getParam);
    for ($counter = 1; $counter < COUNT($getData); $counter++) { // SKIP FIRST URL PARAM BEACAUSE IT IS TABLE NAME NOT PARAM
        $getDataDetail = explode("=",$getData[$counter]);
        $key = $getDataDetail[0];
        $value = $getDataDetail[1];
        $arrayData[$key] = $value;
    }

    return $arrayData; 
}

function analyseReqUrlTableName() {
    // THIS FUNCTION USE TO GET PARAMETER TABLE NAME FROM REQUESTED URL
    // AND CONVERT TO STRING
    $url = $_SERVER['REQUEST_URI'];
    $getTableName = explode("?",$url)[1];
    $getTableData = explode("&",$getTableName)[0];
    $getTableName = explode("=",$getTableData)[1];
    return $getTableName;
}
?>
  