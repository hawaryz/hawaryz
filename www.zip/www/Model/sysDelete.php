<?php
header('Content-Type: application/json; charset=utf-8');
include_once "../Controller/sysDb.php";

if (isset($_GET['SQL'])) {
    $SQL = "_NO_NEED_RETURN_DATA_|||".$_GET['SQL'];
    $jsonReturn = runSQL($SQL,"");
    echo $jsonReturn;
}

?>