<?php
class BuildJSON{
    private $property = array();
    function __construct($data){
        $jsonobj = '['.rtrim($data, ", ").']';

        $arr = json_decode($jsonobj, true);
        $keysLength = COUNT(explode(',"',explode("},", explode("{", $data)[1])[0]));

        
        for ($l = 0; $l < COUNT($arr); $l++){
            for ($j = 0; $j < $keysLength; $j++){$keys = str_replace('"',"", explode(":", explode(',"',explode("},", explode("{", $data)[1])[0])[$j])[0]);
                $value = $arr[$l][$keys];
                $this->property[$l][$keys] = $value; // KEYS BELOM SETTLE...
            }
        }
    }

    function format(){
        $myObj1 = new stdClass();
        $myObj1->success = true;
        $myObj1->data = $this->property;
        $myJSON = json_encode($myObj1);

        $jsondata = $myJSON;
        return $jsondata;
    }
    
    /*
    function format(){
        $data = $this->property;
        for ($list = 0; $list < COUNT($data); $list++) {
            print_r(array_values($data[$list])[1]);
        }
        
        return "";
    }
    */
    
}
?>