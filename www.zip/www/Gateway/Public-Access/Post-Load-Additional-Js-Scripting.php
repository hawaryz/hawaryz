

<!-- BACKEND ALERT POINT -->
<span id="AlertPoint"></span>
<!-- BACKEND ALERT POINT -->

<!-- FRONTEND ERROR ALERT POINT -->
<div id="jsErrorCode" class="ui-content" title="Error Code...!!!">
  <span id="jsErrorCode_text"></span>
</div>
<!-- FRONTEND ERROR ALERT POINT -->

<!-- LOADER SPINNER POINT (NOT USE DUE TO UNSTABLE)-->
<div class="modal fade" id="loaderSpinner" tabindex="-1" role="dialog" aria-labelledby="loadMeLabel">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
        <div class="loaderSpinner"></div>
        <div clas="loader-txtSpinner">
          <p>System Preparing... <br><small>Please Wait</small></p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- LOADER SPINNER POINT -->




<!-- SWEET ALERT POP UP STYLE-->
<!-- UNSTABLE SCRIPT <script src='../Gateway/Private-Access/js/third-party/bootstrap.min.js'></script> -->
<script src='../Gateway/Private-Access/js/third-party/sweetalert.js'></script>
<script type="text/javascript" src="../Gateway/Private-Access/js/common.js"></script>
<script type="text/javascript" src="../Gateway/Private-Access/js/ajax.js"></script>
<script type="text/javascript" src="../Gateway/Private-Access/js/main-js.js"></script>


