<?php
header('Content-Type: application/json; charset=utf-8');
include_once "../Controller/sysDb.php";
include_once "../Config/sysConfig.php";


if (isset($_GET['SQL'])) {
    $SQL = "_NEED_RETURN_DATA_|||".$_GET['SQL'];
    $jsonReturn = runSQL($SQL,"");
    echo $jsonReturn;
}

?>