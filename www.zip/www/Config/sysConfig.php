<?php
function getConfig(){
    $strJsonFileContents = file_get_contents('../Config/Config.json');
    $array = json_decode($strJsonFileContents, true);
    return $array;
}

// GET IS DEBUG MODE
function isDebugMode(){
    return getConfig()["Debugger"]['is_debugMode'];
}
// GET IS DEBUG MODE

// GET DATABASE INFO
function getDatabaseType(){
    if (getConfig()["DataBaseType"]['phpMyAdmin']['active']) {
        $servername = getConfig()["DataBaseType"]['phpMyAdmin']['servername'];
        $username = getConfig()["DataBaseType"]['phpMyAdmin']['username'];
        $password = getConfig()["DataBaseType"]['phpMyAdmin']['password'];
        $dbname = getConfig()["DataBaseType"]['phpMyAdmin']['dbname'];
        return array("dbType"=>"phpMyAdmin","servername"=>"$servername","username"=>"$username","password"=>"$password","dbname"=>"$dbname");
    } else if (getConfig()["DataBaseType"]['SQllite']['active']) {
        $servername = getConfig()["DataBaseType"]['SQllite']['servername'];
        $username = getConfig()["DataBaseType"]['SQllite']['username'];
        $password = getConfig()["DataBaseType"]['SQllite']['password'];
        $dbname = getConfig()["DataBaseType"]['SQllite']['dbname'];
        return array("dbType"=>"SQllite","servername"=>"$servername","username"=>"$username","password"=>"$password","dbname"=>"$dbname");
    }
}
// GET DATABASE INFO

// GET SYSTEM VERSION
function getSystemVersion(){
    return getConfig()["General"]['Sys_Version'];
}
// GET SYSTEM VERSION

// GET SYSTEM NAME
function getSystemName(){
    return getConfig()["General"]['Sys_Name'];
}
// GET SYSTEM NAME
?>
