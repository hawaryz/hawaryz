
      <?php include_once '../Gateway/Public-Access/Pre-Load-Additional-Js-Scripting.php';?> <!-- PASTE THE CODE ON TOP OF HTML CODE -->
        <div id="elementSelectTest">

        </div>
        <div id="datatableArea">

        </div>
        <div id="elementInputArea">

        </div>
        
      <?php include_once '../Gateway/Public-Access/Post-Load-Additional-Js-Scripting.php';?> <!-- PASTE THE CODE ON BOTTOM OF HTML CODE -->

    
    




