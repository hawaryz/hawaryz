BuildTable('stockoutTbl',[`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`],`stockoutTblArea`);
  var table_2 = DatatableInitialize('stockoutTbl');
  DatatableAppendBody(table_2,[[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ],[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ]],0);