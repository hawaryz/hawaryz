BuildTable('manWarrantyTbl',[`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`],`manWarrantyTblArea`);
  var table_1 = DatatableInitialize('manWarrantyTbl');
  DatatableAppendBody(table_1,[[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ],[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ]],0);