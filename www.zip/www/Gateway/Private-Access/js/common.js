//var webservertype=1;	//1 - Apche , 0 -  WebCgi

try {
  document.execCommand("BackgroundImageCache", false, true);
} catch(err) {}

var _usrinfo = null; var _usrname=null; var _usrlogin=null; var _usrlang; var _sessionid=''; var _rptport = 80;
var _usrginfo = '';
var _dLstLogin; var _xLstInFrom;
var _sysbrand = null; var _sysmodel=null; var _sysversion; var _sysname; var _vctallowtype ; var _netprinter ; var _dispenserprinter;
var _xSysTilte = '';
var _sysdev = '';
var _sysos = '';
var _systype ='';

var _deflang = '';
var _genlang = '';
var _custlang = '';
var _admintype=0;
//var _gencss = '';
var _devmode = 0;
var _poweredbyQueueBee='Powered by QueueBee';

var _agt = navigator.userAgent.toLowerCase();
var _is_opera = (_agt.indexOf("opera") != -1);
var _is_ie = (_agt.indexOf("msie") != -1) && document.all && !_is_opera;
var _is_ie5 = (_agt.indexOf("msie 5") != -1) && document.all;
var _is_regexp = (window.RegExp) ? true : false;

var IsMobile = /android|webos|iphone|ipad|ipod|blackberry|unknown/i.test(_agt);

var xmlhttp=getHTTPObject();
function _getusradmininfo()
{
   try{
		
		if (_sessionid=='') 
		{
			_sessionid = _getCookie("queuebeesession");
			//alert(_sessionid);
		}
		
		
	
		if (_usrinfo==null)
		{			
			cgiGetSync('getuinfo.php','type=all');    
			ChkComSyncEx();
			if (_retcmdEx == 'RS')
			{
				window.location.href = '/login.php';
	//			return;
			}
			
			_usrinfo = _retmsgEx;
			_usrname = AutoGetStr(QueryString(_usrinfo,'_sObjNm'));
		//	alert(_usrinfo);
			if(_usrname=='')
				_usrname = AutoGetStr(QueryString(_usrinfo,'_sShortName'));
			
			_usrlang = QueryString(_usrinfo,'_xLang');
			_usrlogin  = QueryString(_usrinfo,'_xLoginID');
			_dLstLogin  = QueryString(_usrinfo,'_dLstLogin2');
			_xLstInFrom  = QueryString(_usrinfo,'_xLstInFrom');
			_xSysTilte = AutoGetStr(QueryString(_usrinfo,'title'));
			$('.weltitle').html( _xSysTilte);
			
			var thesessionid = QueryString(_usrinfo,'sessionid');
			if (thesessionid!='')
				_sessionid = thesessionid;
			//alert(_usrinfo);
			if (_dLstLogin.length>=14)
			{
				
				var newdate = new Date(Number(_dLstLogin.substr(0,4)) , Number(_dLstLogin.substr(4,2))-1 , Number(_dLstLogin.substr(6,2)), Number(_dLstLogin.substr(8,2)), Number(_dLstLogin.substr(10,2)), Number(_dLstLogin.substr(12,2)));
				_dLstLogin = newdate.toLocaleString();
				//alert(_dLstLogin);
				//_dLstLogin = newdate.formatDate('yy');
				//_dLstLogin = _dLstLogin.substr(0,4) + '-' + _dLstLogin.substr(4,2) + '-' + _dLstLogin.substr(6,2) + ' ' +  Number(_dLstLogin.substr(8,2)), Number(_dLstLogin.substr(10,2)), Number(_xLstInFrom.substr(12,2))
				//alert(_dLstLogin.toLocaleDateString());
				//alert(_dLstLogin.toLocaleTimeString());
				//alert(_dLstLogin);
			
			}
	
			//alert(_usrlogin);
			
			if (_usrname.length<=0) _usrname=AutoGetStr(QueryString(_usrinfo,'_sFullName'));
			if (_usrname.length<=0) _usrname = _usrlogin;
			
			if (_usrname.length<=0)
			{
				//setTimeout('window.location.reload();', 1000);
			}
			
			
			_nGrp  = QueryString(_usrinfo,'_nGrp');
			_usrginfo = '';
			if(_nGrp!=0)
			{
				cgiGetSync('getobjectppty.php','type=grpadmn&objid='+_nGrp);    
				ChkComSyncEx();
				if(_retcmdEx=='DT')
				{
					_usrginfo = _retmsgEx;
				}
			}
			
						
			SetObjInnerText('theusername', _usrname);  
			cgiGetSync('getobjectppty.php','type=lic');    
			ChkComSyncEx();
			
			_xLicenseInfo = _retmsgEx;
			_bGotLicense = true;
			//alert(_xLicenseInfo);
			_sysbrand = QueryString(_retmsgEx,'_xBrand');
			_sysmodel = QueryString(_retmsgEx,'_xModel');
			_sysversion = QueryString(_retmsgEx,'_xVersion');
			_vctallowtype = QueryString(_retmsgEx,'_nVCTType');
			_sysname = QueryString(_retmsgEx,'_xSysNm');
			_sysdev = QueryString(_retmsgEx,'_xDev');
			_netprinter  = QueryString(_retmsgEx,'_nMaxNetworkPrinter');
			_dispenserprinter  = QueryString(_retmsgEx,'_nMaxTicketDispenser');
			if(_netprinter=='')_netprinter=0;
			if(_dispenserprinter=='')_dispenserprinter=0;
			 
			if(_sysdev!='')
			{
				$('.device').hide();
				$('.'+_sysdev).show();
			}

			if (typeof webservertype != 'undefined' && webservertype==0)
			{
				cgiGetSync('getobjectppty.php','type=http');    
				ChkComSyncEx();

				_rptport = QueryString(_retmsgEx,'_nHttpReportPort');
				if (_rptport=='')_rptport = 80;
				if(window.location.protocol=='https:')
					_rptport = 443;
			}
			else 
			{
				_rptport = window.location.port;
				if (_rptport=='')_rptport = 80;
				if(window.location.protocol=='https:')
					_rptport = 443;
			}
			
			
			if(_sysbrand=='soraya')_poweredbyQueueBee='';
			
			if(_sysbrand!='QueueBee')
				$('.PwrByQueueBee').html( _poweredbyQueueBee );
		}
	} catch(e) {}


	try
	{
		//Check OS

		_sysos = QueryString(_usrinfo,'sysos');

		_systype = QueryString(_usrinfo,'systype');
		
		_deflang = QueryString(_usrinfo,'_xLang');
		if(_deflang=='')_deflang='en';
		
		_genlang = QueryString(_usrinfo,'genlang');
		
		if(_genlang!='' && typeof(CONST_ALL_LANG_2)=='undefined')
			$.getScript('js/lang_'+_genlang+'_'+_deflang+'.js');

		_custlang = QueryString(_usrinfo,'custlang');
		if(_custlang!='' && typeof(CONST_ALL_LANG_3)=='undefined')
			$.getScript('js/lang_'+_custlang+'_'+_deflang+'.js');
			
		//_gencss = QueryString(_usrinfo,'gencss');
		//if(_gencss!=''){
			//alert(_gencss+','+$('head .indexstyle').size());
		//	$('link.indexstyle').prop('href','css/style_'+_gencss+'.css');
			/*$('head .indexstyle').after(
			$('<link/>', {
			   rel: 'stylesheet',
			   type: 'text/css',
			   href: 'css/style_'+_gencss+'.css'
			}));*/
		//}
		
		
		//IsMobile=true;
		
		if(QueryString(window.location.href,'mobile')=='1' && IsMobile)
		{
			$('.mobilehide').hide();
			$('#main').css('margin-top','0px');
		}
		else if(QueryString(window.location.href,'mobile')=='1')
		{
				$('.mobilehide').hide();
				$('#main').css('margin-top','0px');
				//$('div#main').toggleClass('sidebar-show');
				//setTimeout(MessagesMenuWidth, 250);
		
				//var W = window.innerWidth;
				//var W_menu = $('#sidebar-left').outerWidth();
				//var w_messages = (W-W_menu)*16.666666666666664/100;
				$('#content').width(window.innerWidth);
		
		}
		else if(IsMobile && $(window).width()<=750){
			//alert($(window).width());
			$('.mobiletop').hide();
			$('#main').css('margin-top','50px');
		}
	
	
		updateSysType();
		
		
				
				
				
		//if(typeof(__p_alert_refersh_timer)!='undefined')
		{
			clearTimeout(__p_alert_refersh_timer);
			__p_alert_refersh_timer = setTimeout('alertTimer()',30000);
		}
				
		//clearTimeout(__p_alert_refersh_timer);
		//__p_alert_refersh_timer = setTimeout('alertTimer()',30000);
		
		
		//layout.setDirection('ltr');
		//layout.setDirection('rtl');
		
	}catch(e){
		alert('CHECK OS - ' + e.message);
	}
}
function updateSysType(){
	if(_systype=='ccs')
		$('.nccs').data('isHide','1').hide();	//not for ccs will hide (while is css type)
	else $('.ccs').data('isHide','1').hide();	// is not for css will hide
	
	if(_sysos=='android')$('.winonly,.linuxonly,.notandroid').hide();
	else if(_sysos=='win32')$('.androidonly,.linuxonly,.notwind32').hide();
	else if(_sysos=='linux')$('.winonly,.androidonly,.notlinux').hide();
	
	
	if( _usrlogin != 'hyAdmin' && _usrlogin != 'qbAdmin' &&  _usrlogin != 'Admin' && _usrlogin != 'dealer' ){/*$('.generaladmin').hide();*/_admintype=1;}	//generaladmin not use
	if( _usrlogin != 'hyAdmin' && _usrlogin != 'qbAdmin' &&  _usrlogin != 'dealer'  ){$('.adminonly').hide();_admintype=1;}
	
	if( _usrlogin == 'Admin'){_admintype=9;}
	else if( _usrlogin == 'dealer'){_admintype=10;}
	else if( _usrlogin == 'hyAdmin'){_admintype=11;}
	else if( _usrlogin == 'qbAdmin'){_admintype=12;}
	
	if( _usrlogin != 'hyAdmin' &&  _usrlogin != 'qbAdmin'){$('.hyqbonly').hide();}

	if( _usrlogin != 'hyAdmin' ){$('.hyadminonly').hide();}
	if( _usrlogin != 'qbAdmin' ){$('.qbadminonly').hide();}
	
	if( _usrlogin != 'hyAdmin' &&  _usrlogin != 'qbAdmin' &&  _usrlogin != 'dealer'){$('.hyqbdonly').hide();}
	else $('.hyqbdonly').show();
	
	if(QueryString(_usrinfo,'_nFunc@0')=='1')
	{
		for(m=0 ; m<25 ; m++)
		{	//turn on for
			if(QueryString(_xLicenseInfo, '_nSys@'+m)=='0')continue;
			$('.comp_sys_' + m).show();
		}
	}
	
	if(QueryString(_usrinfo,'_nFunc@0')=='0')
		$('.masteradmin').hide();
	
	
}
var __p_alert_refersh_timer;
var xmlhttpAlert=getHTTPObject();
function alertTimer(){
	clearTimeout(__p_alert_refersh_timer);
	//return;
	try
	{
		var u = 'getalert.php';
		var d = 'type=message';
		
		var tm = Math.random()*1000 + Math.random()*100 + Math.random()*10;; 
		var s;	
		if (typeof webservertype != 'undefined' && webservertype==0)
			s=u+"?Now="+tm;	
		else
		{
			
			//s="/testrequest.php?Now="+tm+"&usrid="+_usrlogin+"&sessionid"+_sessionid;
			s="/requestserver.php?function="+u+"?Now="+tm+"&usrid="+_usrlogin+"&svrtype=ctrsvr&sessionid="+_sessionid;
			//alert(s);
			
		}	
		//alert(webservertype);	
		if (d!="") s=s+"&"+d;    
		try
		{    
			xmlhttpAlert.open("GET", s, false);
		}
		catch (e)
		{
			//alert("2 - " + e);
			//xmlhttpAlert.onreadystatechange=function(){return;};
			xmlhttpAlert=getHTTPObject();
			xmlhttpAlert.open("GET", s, false);
		}   
	
	
		xmlhttpAlert.onreadystatechange=function(){
			if (xmlhttpAlert.readyState==4){    
			   // var cmd=GetCmd();
			   // var data=GetData();
				var cmd=xmlhttpAlert.responseText.substr(0,2);
				var data=xmlhttpAlert.responseText.substr(2);
			
				if (cmd=='RS')
				{
					window.location.href = '/login.php';
				}
				else if(cmd =='OK')
				{
					$('.alertmsg').removeClass('alertnone').addClass('alerticon').css('color','red');
					$('.alertbadge').html(data);
					playVoice();
				}
				else if(data.indexOf('login.php')!=-1)
				{
					window.location.href = '/login.php';
				}
				else 
				{
					$('.alertmsg').addClass('alertnone').removeClass('alerticon').css('color','');
					$('.alertbadge').html('');
				}
			}
			else
			{
				
			}
			
			xmlhttpAlert.onreadystatechange = {};
					
			var alertTimer = 5000;
			if(_is_ie)alertTimer=30000;
			__p_alert_refersh_timer = setTimeout('alertTimer()',alertTimer);
			
		};
	    xmlhttpAlert.send(null);
		
	
	}catch(e)
	{
		clearTimeout(__p_alert_refersh_timer);
		var alertTimer = 15000;
		if(_is_ie)alertTimer=30000;
		__p_alert_refersh_timer = setTimeout('alertTimer()',alertTimer);
	}
	
}

function playVoice(){
	try
	{
		var audio = new Audio();
		var theTypeID = 'voice_';
		//if(audio.canPlayType('audio/ogg'))theTypeID += 'ogg';
		//else 
		if(audio.canPlayType('audio/mpeg'))theTypeID += 'mp3';
		else if(audio.canPlayType('audio/wav'))theTypeID += 'wav';
		//else if(audio.canPlayType('audio/aac'))theTypeID += 'aac';
		delete audio;
		
		var thissound=document.getElementById(theTypeID);
		//alert('PlayVoice '+theTypeID);
		thissound.pause();
		thissound.load();
		thissound.play();
	}catch(e)
	{
		
		//alert('PlayVoice - '+e.message);
	}
}
function _getCookie(Name){ 
		var re=new RegExp(Name+"=[^;]+", "i"); //construct RE to search for target name/value pair
		if (document.cookie.match(re)) //if cookie found
			return document.cookie.match(re)[0].split("=")[1]; //return its value
		return null;
	}

function _setCookie(name, value){
		//document.cookie = name + "=" + value
		date = new Date();
        date.setFullYear(date.getFullYear()+1);
        document.cookie = name + "=" + escape(value) + "; expires=" + date.toGMTString();

	}

var _pagelang = _getCookie("crxLang");

/*
function _onRemove(func_name)
{
	var msg = QueryLangString('mrmvnw');
	if (ObjVal('_sObjNm')!='')
		msg = QueryLangString("lrmv") + ' ' + ObjVal('_sObjNm') + ' ?';   
	else if (_objname!=null)
		msg = QueryLangString("lrmv") + ' ' + AutoGetStr(_objname) + ' ?';   
   var rt=confirm(msg);
   if (rt!=true) return;

	var s = "type=" + _type;
	//alert(_parentID);
	if (typeof _parentID!='undefined') 
		s = s + '&parentid=' + _parentID;

	if (typeof _objID!='undefined') 
		s=s+'&objid=' + _objID;

	s = s +OnApplyEvent();
	
	if (typeof func_name == 'undefined' || func_name=='' || func_name == null)
		cgiGetSync("removeitem.php",s);
	else	
		cgiGetSync(func_name,s);
	ChkComSyncEx();
    
	if (typeof _prtpage != 'undefined')
	{
		window.location.href = _prtpage;	
	}
 /*   if (_retcmdEx=='OK')
        alert(QueryLangString('laplyok'));
    else
        alert(QueryLangString('laplynok') + '\n' + _retmsgEx);*/
//}

function getqstr(name){
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var s;
  if (typeof (__content_url) == 'undefined')
		s=window.location.href;
	else
		s=__content_url;
  var pt=/%20/g;
  s=s.replace(pt,' ');
  var results = regex.exec(s);
  if( results == null )
    return "";
  else
  {
    return results[1];
  }
}  
function QueryString(source,name){
  name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var _s=source;
  var pt=/%20/g;
  _s=_s.replace(pt,' ');  
  var results = regex.exec(_s);
  if( results == null )
    return "";
  else
  {
    return results[1];
  }
}

function QueryLangString(name){
    var _n,_s="";
    if(typeof(CONST_ALL_LANG_3)!='undefined')
	{
		for (_n=0;_n<CONST_ALL_LANG_3.length;_n++)
		{
			_s=QueryString(CONST_ALL_LANG_3[_n], name);
			if(_s!="") return _s;
		}
	}
	
	if(typeof(CONST_ALL_LANG_2)!='undefined')
	{
		for (_n=0;_n<CONST_ALL_LANG_2.length;_n++)
		{
			_s=QueryString(CONST_ALL_LANG_2[_n], name);
			if(_s!="") return _s;
		}
	}
	
	
	if(typeof(CONST_ALL_LANG)!='undefined')
	{
		for (_n=0;_n<CONST_ALL_LANG.length;_n++)
		{
			_s=QueryString(CONST_ALL_LANG[_n], name);
			if(_s!="") return _s;
		}
	}
	
    return "";
}
function _GetRandomNo()
{
    var dt = new Date();    
    var tm = dt.getDate()+dt.getTime();
    var s = "rand="+tm;
    return s;
}



function cgiGet(u,d){    
    var dt = new Date();    
    var tm = dt.getDate()+dt.getTime();  
	var s;	
	if (typeof webservertype != 'undefined' && webservertype==0)
		s=u+"?Now="+tm+"&sessionid="+_sessionid;
	else
		s="/requestserver.php?function="+u+"?Now="+tm+"&usrid="+_usrlogin+"&svrtype=ctrsvr&sessionid="+_sessionid;
	//alert(s+','+webservertype);
    if (d!="") s=s+"&"+d;    
    //var __s = "http://" + window.location.host + "/" + s;
    //alert(__s);
    try
    {    
        xmlhttp.onreadystatechange=function(){return;};    
        xmlhttp.open("GET", s, true);
    }
    catch (e)
    {
        //alert("1 - " + e);
        xmlhttp=getHTTPObject();
        xmlhttp.open("GET", s, true);
    }
}
function cgiGetSync(u,d){
    var dt = new Date();    
    var tm = dt.getDate()+dt.getTime();  
	var s;	
	if (typeof webservertype != 'undefined' && webservertype==0)
		s=u+"?Now="+tm+"&sessionid="+_sessionid;	//add in  sessionid , stupid always got problem
	else
	{
		
		//s="/testrequest.php?Now="+tm+"&usrid="+_usrlogin+"&sessionid"+_sessionid;
		// s=u+"?"+d;
		s=u;
		// alert(s);
		
	}	
	//alert(webservertype);	
    // if (d!="") s=s+"&"+d;    
	// alert(s);
    try
    {    
        xmlhttp.open("GET", s, false);
    }
    catch (e)
    {
        //alert("2 - " + e);
        xmlhttp=getHTTPObject();
        xmlhttp.open("GET", s, false);
    }        
}

var _retcmdEx;
var _retmsgEx;
function ChkComSyncEx(){    
    xmlhttp.send(null);
        if (xmlhttp.readyState==4){                  
		
		
			//var headers = xmlhttp.getAllResponseHeaders().toLowerCase();
			//alert(headers);
		
	        var cmd=GetCmd();
	        var data=GetData();
	        _retcmdEx = cmd;
	        _retmsgEx = data;
			
			if (cmd=='RS')
			{
				window.location.href = '/login.php';
			}
	    }
}

function getHTTPObject() {
    if (typeof XMLHttpRequest != 'undefined') {
        return new XMLHttpRequest();}
    try { return new ActiveXObject("Msxml2.XMLHTTP");} 
    catch (e) {
        try { return new ActiveXObject("Microsoft.XMLHTTP");} 
        catch (e) {}}
    return false;
}
function Int2Str(a,n) {
    var s=a.toString();
    for(var i=s.length;i<n;i++)
        s="0"+s;
    return s;
}
function UniCVal16base(_s)
{
    var _a="";
    var _n, _c;
    for (_n=0 ; _n<_s.length ; _n++) {
        _c = _s.charCodeAt(_n).toString(16);
        _c = Int2Str(_c,4);
        _a=_a+_c;
    }
    return _a;
}
function ObjUniCVal16base(s){
    var _s=document.getElementById(s).value;
    return UniCVal16base(_s);
}
function ObjUniCVal10base(s){
    var _s=document.getElementById(s).value;
    var _a="";
    var _n, _c;
    for (_n=0 ; _n<_s.length ; _n++) {
        _c = _s.charCodeAt(_n).toString();
        _a=_a+_c;
    }
    return _a;
}
function AutoGetStr(_s)
{
	//alert(_s);
    if (_s==null) return _s;
    if (_s.length<4) return _s;    
    if (_s.substr(0,4)=='_u_u') return Cvt2UniC(_s);
	else if (_s.substr(0,4)=='_d_t')
	{	//_d_tddd130228HHMMSS
		try
		{

			if (_s.length<19) return _s.substr(4);    
			var _thestrdttm = new Date(2000+Number(_s.substr(7,2)), Number(_s.substr(9,2)), Number(_s.substr(11,2)), 
										Number(_s.substr(13,2)), Number(_s.substr(15,2)), Number(_s.substr(17,2)));
			if (_s.substr(4,3)=='ddd') 
				return 	_thestrdttm.toLocaleDateString();
			else if (_s.substr(4,3)=='ttt') 
				return 	_thestrdttm.toLocaleTimeString();
			else
				return 	_thestrdttm.toString();			
		}	
		catch(e){return e;}		
		return;
		//return Cvt2UniC(_s);
	}	
    else if (_s.substr(0,4)=='_l_l')
    {
        if (CONST_ALL_LANG) _s=QueryLangString(_s.substr(4));
    }
    return _s;
}
function Cvt2UniC(_s){    
    var _a, _b;
    var _n, _m, _pos=0;
    _b="";
    
    if (_s==null) return _b;
    if (_s.length<4) return _b;    
    if (_s.substr(0,4)=='_u_u') _pos=4;
    
    for (_n=_pos ; _n<_s.length-3 ; _n+=4){
        _a="0x";
        for (_m=_n;_m<_n+4;_m++) _a=_a+_s.charAt(_m);
        //if (_a>=0x20)
		//alert(_a);
			_b=_b+String.fromCharCode(_a);
			
    }
    return _b;
}
function ObjByID(s){return document.getElementById(s);}
function ObjByName(s){return document.getElementsByName(s);}
function ObjVal(s){if (document.getElementById(s)==null)return ""; return document.getElementById(s).value;}
function SetObjVal(o,s){
	if (document.getElementById(o)==null)return;
    if (s==null) document.getElementById(o).value='';
    else document.getElementById(o).value=s;}
function SetObjValByName(o,s){
	if (document.getElementById(o)==null)return;
    if (s==null) document.getElementsByName(o).value='';
    else document.getElementsByName(o).value=s;}
function SetObjInnerText(o,s){
	if (document.getElementById(o)==null)return;
    if (s==null) document.getElementById(o).innerHTML='';
    else document.getElementById(o).innerHTML=s;}
function GetObjInnerText(o){
	if (document.getElementById(o)==null)return '';
    return document.getElementById(o).innerHTML;}
function SetObjInnerTextByName(o,s){
	if (document.getElementById(o)==null)return;
    if (s==null) document.getElementsByName(o).innerHTML='';
    else document.getElementsByName(o).innerHTML=s;}
function ObjChecked(s){if (document.getElementById(s)==null)return "0"; return (document.getElementById(s).checked==true?"1":"0");}
function ObjCheckedInTrueFalse(s){return (document.getElementById(s).checked==true?"True":"False");}
function CheckObj(s,v){
	if (document.getElementById(s)==null)return;
    if (v=="1") document.getElementById(s).checked=true;
    else document.getElementById(s).checked=false;
}
function IsTrueFalse(s){
    if (s=="1" || s=="true" || s=="True") 
        return true;
    return false;
}
function IsNumber(s){
    var n, v=ObjVal(s);
    n = Number(v);
    if (v=="") return false;
    if (n.toString()=='NaN'||n==null)
	    return false;
	return true;
}

function FillCB(m,b,t,d){
    var cb,o,n,s;    
    cb=ObjByID(m);
    if (cb==null)return;
    for (n=b;n<t;n++){
        o=document.createElement("option");
        cb.options.add(o,n);
        s=Int2Str(n,d);
        o.text=s;
        o.value=s;}
}
function FillCBWithData(m,s){
    var n, ss, sss, o;    
    cb=ObjByID(m);
    if (cb==null)return;
    ss = s.split('|');
    for (n=0;n<ss.length;n++){
        if (ss[n].length<2) break;
        sss = ss[n].split('^');
        o=document.createElement("option");
        cb.options.add(o);
        o.text=sss[1];
        o.value=sss[0];
    }
}

function CBSelect(m,s){
    var cb=ObjByID(m);
    for (var j=0;j<cb.options.length;j++){        
        if (cb.options[j].value==s){
            cb.options[j].selected = true;
            break;
    }}
}

function CBRemoveAll(m){
    var cb=ObjByID(m);
    while(cb.options.length>0) cb.remove(0);
}
function prmOK(){
    alert(QueryLangString('lblapplysucs'));
}
function prmOKWithRestart(){
    alert(QueryLangString('lblapplysucsrstnow'));
}
function prmRestartNow(){
    alert(QueryLangString('lblrestartnow'));
}
function prmKO(s){
var a=QueryLangString('lblapplyfail');
if (s.length>2) a=a+"\n"+s;
alert(a);
}

function shwreply(__cmd,__data){
	if (__cmd=='KO')
		prmKO(__data);
	else if (__cmd=='OO' && __data.length>0)
		alert(QueryLangString(__data));
	else if (__cmd=='OK')
		alert(QueryLangString('lblapplysucs'));
	else if (__cmd=='MS' && __data.length>0)
		alert(QueryLangString(__data));		
}

function RestartDevice(t,p,d){
var rt=confirm(QueryLangString('mrstnow'));if (rt!=true) return;
cgiGet('restartdevice.cgi','type='+t+'&parentid='+p+'&objid='+d); 
ChkCom();
}
function DwlFrmt(d){var rt=confirm("Download ticket format now?");if (rt!=true) return;
cgiGet('dwlfrmt.cgi','objid='+d); ChkCom();}
function GetCmd(){return xmlhttp.responseText.substr(0,2);}
function GetData(){return xmlhttp.responseText.substr(2);}
function CBInsert(s,t,v){ 
    var cb,o;
    cb=document.getElementById(s);
	o = document.createElement("option");
    cb.options.add(o);
//	alert('CBInsert - ' + t );
    o.text=t;
    o.value=v;
}
function CBInsert2OptGroup(g,t,v){
    var o = document.createElement("option");
    o.text=t;
    o.value=v;
    g.appendChild(o);
}
function CBInsertOptGroup(g,t){
    var _grp = document.createElement("optgroup");
    _grp.label=t;    
    g.appendChild(_grp);
    return g;
}

var sConstNA='- Not Assigned -';
var sConsttmReload=500;

/*function _pageload()
{
    //alert(document.forms.length);
    if (document.forms.length==0) return;
    var n;
    for (n=0 ; n < document.forms[0].childNodes.length ; n++)
    {
        var thenode=document.forms[0].childNodes[n];        
        //alert(thenode.id);
        _ChangeChildLang(thenode);
        
    } 
}*/

function _pageload()
{
    //alert(document.forms.length);
    if (ObjByID('mainframe')==null) return;
    var n;
    for (n=0 ; n < ObjByID('mainframe').childNodes.length ; n++)
    {
        var thenode=ObjByID('mainframe').childNodes[n];        
        //alert(thenode.id);
        _ChangeChildLang(thenode);
        
    } 
}
function _ChangeChildLang(orgnode)
{
    try{
        if (orgnode.childNodes.length==0) return;
        var n, val, name;
        for (n=0 ; n < orgnode.childNodes.length ; n++)
        {
            var thenode=orgnode.childNodes[n];        
            //alert(thenode.id);
            _ChangeChildLang(thenode);
            if (thenode.id==null)continue;
            name=thenode.id.toString();
            if (name=="" || name=="undefined")continue;
            val = QueryLangString(name);
            if (val=="")continue;
            thenode.innerHTML=val;
            /*alert(n + " id= " + thenode.id + ", name=" +
                       thenode.name + ", innerHtml=" +
                       thenode.innerHTML + ", value=" +
                       thenode.value);*/
        }
    }
	catch(e) {}
}
/*function FillInValue(strUrl)
{
    if (document.forms.length==0) return;
    var n;
    for (n=0 ; n < document.forms[0].childNodes.length ; n++)
    {
        var thenode=document.forms[0].childNodes[n];        
        _FillInChildValue(strUrl, thenode);        
    } 
}
*/
function FillInValue(strUrl , strParentNodeId)
{
	if(typeof(strParentNodeId)=='undefined')strParentNodeId = 'mainframe';
    if (ObjByID(strParentNodeId)==null) return;
    var n;
    for (n=0 ; n < ObjByID(strParentNodeId).childNodes.length ; n++)
    {
        var thenode=ObjByID(strParentNodeId).childNodes[n];        
        _FillInChildValue(strUrl, thenode);        
    } 
}

function _FillInChildValue(strUrl, orgnode)
{
    try{
        if (orgnode.childNodes.length==0) return;
        var n, val, name;
        for (n=0 ; n < orgnode.childNodes.length ; n++)
        {
            var thenode=orgnode.childNodes[n];        
            //alert(thenode.id.toString());
            _FillInChildValue(strUrl, thenode);
            if (thenode.id==null)continue;
            name=thenode.id.toString();
            if (name=="" || name=="undefined")continue;
            
            if (name.charAt(0)!='_')continue;            
            //alert("pass");
            val = QueryString(strUrl, name);
            
            //alert(name);
            //alert(val);

            if (name.charAt(1)=='b')
            {
                if (val=="") val="0";
                CheckObj(name, val);
            }
            else if (name.charAt(1)=='s')
                SetObjVal(name, Cvt2UniC(val));
            else            
                SetObjVal(name, val);
        }
    }
	catch(e) {}
}
/*
function OnApplyEvent(strUrl)
{
    var strRet="";
	
    if (document.forms.length==0) return strRet;
    var n;
    for (n=0 ; n < document.forms[0].childNodes.length ; n++)
    {
        var thenode=document.forms[0].childNodes[n];        
        strRet = strRet + _OnApplyEvent(strUrl, thenode);        
    } 
    return strRet;
}
*/

function OnApplyEvent(strUrl)
{
    var strRet="";
	
	if(__extra_apply_object == '')__extra_apply_object = 'mainframe';
	
    if (ObjByID(__extra_apply_object)==null) return strRet;
    var n;
    for (n=0 ; n < ObjByID(__extra_apply_object).childNodes.length ; n++)
    {
        var thenode=ObjByID(__extra_apply_object).childNodes[n];        
        strRet = strRet + _OnApplyEvent(strUrl, thenode);        
    } 
    return strRet;
}

function _OnApplyEvent(strUrl, orgnode)
{
    var strRet="";
    try{
        if (orgnode.childNodes.length==0) return "";
        var n, val, name;
        for (n=0 ; n < orgnode.childNodes.length ; n++)
        {
            var thenode=orgnode.childNodes[n];        
            strRet = strRet + _OnApplyEvent(strUrl, thenode);
            if (thenode.id==null)continue;
            name=thenode.id.toString();
            //alert("1 - " + name);
            if (name=="" || name=="undefined")continue;                        
            if (name.charAt(0)!='_')continue;            
            if (name.charAt(1)=='b')
                strRet = strRet + "&" + name + "=" + ObjCheckedInTrueFalse(thenode.id);
            else if (name.charAt(1)=='n' || name.charAt(1)=='f' || name.charAt(1)=='x')
                strRet = strRet + "&" + name + "=" + ObjVal(thenode.id);
            else if (name.charAt(1)=='s')
            {
                strRet = strRet + "&" + name + "=" + ObjUniCVal16base(thenode.id);
            }
                
        }
    }
	catch(e) {}
	return strRet;
}

function _SetPageDir()
{
	//alert('_SetPageDir');
    var _thelang = QueryString(parent.location.href,"lang");
    if (_thelang!="" && _pagelang!=null)
    {
        if (_pagelang!=_thelang)
        {
            _setCookie("crxLang", _thelang);
            parent.location.href = parent.location.href;
        }
    }

    if (_pagelang!=null)
    {
        if (_pagelang=="ar") document.dir= "rtl";
         
        if (document.getElementById('sellang')!=null && _pagelang.length>0)
        {
            CBSelect("sellang",_pagelang);    
        }        
    }
}

function AutoFillCB(_id, _data)
{
    var rows = _data.split('|');
    var n;
    for (n=0;n<rows.length;n++)
    {
        if (rows[n].length<=2) break;
        var cols = rows[n].split('^');
        if (cols[0].length<=0 || cols[1].length<=0) break;
        CBInsert(_id,cols[0],cols[1]);
    }
}
function AutoFillCBWithUnicode(_id, _data)
{
    var rows = _data.split('|');
    var n;
    for (n=0;n<rows.length;n++)
    {
        if (rows[n].length<=2) break;
        var cols = rows[n].split('^');
        if (cols[0].length<=0 || cols[1].length<=0) break;
        CBInsert(_id,Cvt2UniC(cols[0]),cols[1]);
    }
}
function LastDayOfMonth(Year, Month)
{
    return(new Date((new Date(Year, Month+1,1))-1)).getDate();
}
function restartsystem(needcfrm)
{
    if (needcfrm!=null && needcfrm=="1")
    {
	    var rt=confirm(QueryLangString('msgRstrtSys'));
        if (rt!=true) return;
    }
    cgiGet("restartsystem.cgi",'');
    xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState==4){
            try{
	            var cmd=GetCmd();
	            var data=GetData();
	            if (cmd=="OK"){
	                var _strHTML = 'Please wait, system is being restarted... ' + 
	                            ' <script language="javascript" type="text/javascript"> ' +
	                            ' setTimeout(\'parent.location.href = "http://" + parent.location.host + "/login.html"\', 10000);' +
	                            ' <\/script>';
	                document.write(_strHTML); 
	            }
                else prmKO(data);
			}
			catch(e) {alert(e);}
			xmlhttp.onreadystatechange = {};			
	    }
	};
	xmlhttp.send(null);
}
function restartwindow(needcfrm)
{
    if (needcfrm!=null && needcfrm=="1")
    {
	    var rt=confirm(QueryLangString('msgRstrtWin'));
        if (rt!=true) return;
    }
    cgiGet("restartwindow.cgi",'pass=eqsAdmin');
    xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState==4)
        {
            xmlhttp.onreadystatechange = {};
	    }
	};
	xmlhttp.send(null);
}
function shutdownwindow(needcfrm)
{
    if (needcfrm!=null && needcfrm=="1")
    {
	    var rt=confirm(QueryLangString('msgShutDownWin'));
        if (rt!=true) return;
    }
    cgiGet("shutdownwindow.cgi",'pass=eqsAdmin');
    xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState==4)
        {
            xmlhttp.onreadystatechange = {};
	    }
	};
	xmlhttp.send(null);
}

function resetqueue(needcfrm)
{
    if (needcfrm!=null && needcfrm=="1")
    {
	    var rt=confirm(QueryLangString('msgRstrtQue'));
        if (rt!=true) return;
    }
    cgiGet("resetqueue.cgi",'pass=eqsAdmin');
    xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState==4){
            try{
	            var cmd=GetCmd();
	            var data=GetData();
	            if (cmd=="OK"){
	                prmOK();
	            }
                else prmKO(data);
			}
			catch(e) {alert(e);}			
			xmlhttp.onreadystatechange = {};
	    }
	};
	xmlhttp.send(null);
}
function restartrptservice(needcfrm)
{
    if (needcfrm!=null && needcfrm=="1")
    {
	    var rt=confirm(QueryLangString('msgRstrtRptSrv'));
        if (rt!=true) return;
    }
    cgiGet("restartrptsrv.cgi",'pass=eqsAdmin');
    xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState==4){
            try{
	            var cmd=GetCmd();
	            var data=GetData();
	            if (cmd=="OK"){
	                prmOK();
	            }
                else prmKO(data);
			}
			catch(e) {alert(e);}			
			xmlhttp.onreadystatechange = {};
	    }
	};
	xmlhttp.send(null);
}

function AddNewObj(_prnt, _obj, _id, _attr)
{
    var _theObj;
	try{ _theObj = document.createElement( '<'+_obj + ' ' + _attr + '>' );}
	    catch (e) {
	        _theObj = document.createElement( _obj );
	        var atr = _attr.split(' ');
	        var __n;
	        for (__n=0;__n<atr.length;__n++)
	        {
	            if (atr[__n].length<2)break;
				
				var p = atr[__n].indexOf('=');
				if (p<1) continue;
				
				var theatr = atr[__n].substr(0, p);
				var s = atr[__n].substr(p+1);
				
	            s=s.replace(/\"/gi, '');
				s = s.replace(/&nbsp;/g, ' ');
				
				
//	            var atrnm= atr[__n].split('=');
//	            if (atrnm[0].length<2) break;
//	            var s=atrnm[1].replace('"', '');
//	            s=s.replace('"', '');
//				s = s.replace(/&nbsp;/g, ' ');
//	            _theObj.setAttribute(atrnm[0], s);
				
				_theObj.setAttribute(theatr, s);
				
				
	        }
    }
    if (_id!="") _theObj.id = _id;
    _prnt.appendChild(_theObj);
    return _theObj;
}  

function ChkComStandardReply(){
    xmlhttp.onreadystatechange=function(){
        if (xmlhttp.readyState==4){
            try{
	            var cmd=GetCmd();
	            var data=GetData();
	            if (cmd=="GT"){
	                FillInValue(data);
                }
                else if (cmd=="ST") {}
                else if (cmd=="OK") 
                {
                    prmOK();
                }
                else alert(data);
			}
			catch(e) {alert(e);}			
			xmlhttp.onreadystatechange = {};
	    }
	};
	xmlhttp.send(null);
}

function AddTblObj(_prnt, _obj, _id, _attr)
{
    var _theObj;
	try{ _theObj = document.createElement( '<'+_obj + ' ' + _attr + '>' );}
	    catch (e) {
	        _theObj = document.createElement( _obj );
	        var atr = _attr.split(' ');
	        var __n;
	        for (__n=0;__n<atr.length;__n++)
	        {
	            if (atr[__n].length<2)break;
				//alert(atr[__n]);
				var p = atr[__n].indexOf('=');
				if (p<1) continue;
				
				var theatr = atr[__n].substr(0, p);
				//alert(theatr);
				var s = atr[__n].substr(p+1);
				
	            //var atrnm= atr[__n].split('=');
	            //if (atrnm[0].length<2) break;
	            //var s=atrnm[1].replace('"', '');
	            s=s.replace(/\"/gi, '');
				s = s.replace(/&nbsp;/g, ' ');
				
				
				//alert(theatr + '=' + s + ', atr len=' + theatr.length + ', s len=' + s.length);
				
				
	            //_theObj.setAttribute(atrnm[0], s);
				_theObj.setAttribute(theatr, s);
	        }
    }
    if (_id!="") _theObj.id = _id;
    _prnt.appendChild(_theObj);
    return _theObj;
}

function AddCol(_tr, _id, _mod, _isflt, _other)
{
    var _th;
    var ss = "";
    var _s = "";
    if (_other==null)_other="";
   // if (_isflt!="") ss = "table-filterable ";
   // if (_mod!="") ss= ss + "table-sortable:" + _mod + " ";
    try{
        if (ss=="" && _other=="")
        {
            _th = document.createElement( '<TH>' );
        } 
        else
        {
            _s = '<TH ';
            if (ss!="") _s =  _s + ' class = "'+ss+'" ';
            if (_other!="") _s = _s + _other;
            _s = _s + ' >';
            _th = document.createElement(_s);
        }
    }
	catch (e) {
	    _th = document.createElement( 'TH' );
	    if (_mod!="") _th.setAttribute('class', ss);
	    if (_other!="")
	    {
	        _s = _other.split('=');
	        _th.setAttribute(_s[0], _s[1]);
	    }
    }
    if (_id!="") _th.id = _id;
    _tr.appendChild(_th);
    //_tTtlCol++;
}

function str2dttm(s)
{ 
	if (s.length<14) return '';	
	return 	s.substr(0,4) + '-' + s.substr(4,2) + '-' + s.substr(6,2) + ' ' + s.substr(8,2) + ':' + s.substr(10,2) + ':' + s.substr(12,2);
		
}
function withoutdecimal(a,n)
{
    var s=a.toString();
	var p=s.indexOf('.');
	if (p>0)
	{	
		s=s.substr(0, p);
	}
    for(var i=s.length;i<n;i++)
        s="0"+s;
    return s;
}

var _bGotLicense = false;
var _xLicenseInfo = '';
/*function getlicenseinfo()
{
	if (_bGotLicense) return _xLicenseInfo;
	cgiGetSync('getsysinfo.php','type=lic');    
    ChkComSyncEx();	
	_xLicenseInfo = _retmsgEx;
	_bGotLicense = true;
	return _xLicenseInfo;
}*/
  
function pageWidth() {return window.innerWidth != null? window.innerWidth : document.documentElement && document.documentElement.clientWidth ?       document.documentElement.clientWidth : document.body != null ? document.body.clientWidth : null;} function pageHeight() {return  window.innerHeight != null? window.innerHeight : document.documentElement && document.documentElement.clientHeight ?  document.documentElement.clientHeight : document.body != null? document.body.clientHeight : null;} function posLeft() {return typeof window.pageXOffset != 'undefined' ? window.pageXOffset :document.documentElement && document.documentElement.scrollLeft ? document.documentElement.scrollLeft : document.body.scrollLeft ? document.body.scrollLeft : 0;} function posTop() {return typeof window.pageYOffset != 'undefined' ?  window.pageYOffset : document.documentElement && document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop ? document.body.scrollTop : 0;} function posRight() {return posLeft()+pageWidth();} function posBottom() {return posTop()+pageHeight();}

function formatdatetime(dt)
{
	return dt.toLocaleString();
	//return ((dt.getFullYear()).toString() + '-' + (dt.getMonth()+1).toString() + '-' + dt.getdate().toString() + ' ' + dt.getHou);
}
function formatdatetime2(dt)
{
	return dt.getFullYear() + 
			Int2Str((dt.getMonth()+1), 2)+ 
			Int2Str(dt.getDate(), 2) + 
			Int2Str(dt.getHours(), 2) + 
			Int2Str(dt.getMinutes(), 2) + 
			Int2Str(dt.getSeconds(), 2);
}

function formattime1(dt)
{
	var nHour = dt.getHours();
	var xAMPM = 'AM';
	
	if (nHour==0) nHour=12;
	else if (nHour>=12)
	{
		xAMPM = 'PM';		
		if (nHour>12) nHour = nHour - 12;
	}
	 
	return nHour + ':' + ("0" + dt.getMinutes()).slice(-2) + ' ' + xAMPM; 	
}

function formattime2(dt)
{
	var nHour = dt.getHours();
	var xAMPM = 'AM';
	
	if (nHour==0) nHour=12;
	else if (nHour>=12)
	{
		xAMPM = 'PM';		
		if (nHour>12) nHour = nHour - 12;
	}
	 
	return nHour + ':' + ("0" + dt.getMinutes()).slice(-2) + ':' + ("0" + dt.getSeconds()).slice(-2) + ' ' + xAMPM; 	
}

function formatsimpledatetime(dt)
{
		var curr_date = dt.getDate();
		var curr_month = dt.getMonth() + 1; //Months are zero based
		var curr_year = dt.getFullYear();
	
		return curr_date + "/" + curr_month + "/" + curr_year;
}
function formatsimpledatetime2(dt)
{
		var curr_date = dt.getDate();
		var curr_month = dt.getMonth() + 1; //Months are zero based
		var curr_year = dt.getFullYear();
	
		return curr_year + "-" + curr_month + "-" + curr_date ;
}

function getdatetimefromstring(_sDt)
{
	var nPos=0;
	var theYear = 2000;
	if (_sDt.length==12)
	{
		theYear = 2000 + Number(_sDt.substr(0,2));
		nPos=2;
	}
	else if (_sDt.length==14)
	{
		theYear = Number(_sDt.substr(0,4));
		nPos=4;
	}
	else
		return new Date();
	
	
	var theMonth = Number(_sDt.substr(nPos,2))-1;
	var theDay = Number(_sDt.substr(nPos+2,2));
	var thedt = new Date(theYear,theMonth,theDay);
	
	thedt.setHours(Number(_sDt.substr(nPos+4,2)));
	thedt.setMinutes(Number(_sDt.substr(nPos+6,2)));
	thedt.setSeconds(Number(_sDt.substr(nPos+8,2)));
	return thedt;
	
	/*
	
	var thedt = new Date();
	if (_sDt.length==12)
	{
		thedt.setFullYear(2000+Number(_sDt.substr(0,2)));
		nPos=2;
	}
	else if (_sDt.length==14)
	{
		thedt.setFullYear(Number(_sDt.substr(0,4)));
		nPos=4;
	}
	else
		return;
		
	thedt.setMonth(Number(_sDt.substr(nPos,2))-1);
	thedt.setDate(Number(_sDt.substr(nPos+2,2)));
	thedt.setHours(Number(_sDt.substr(nPos+4,2)));
	thedt.setMinutes(Number(_sDt.substr(nPos+6,2)));
	thedt.setSeconds(Number(_sDt.substr(nPos+8,2)));
	return thedt;
	*/
}

function getdatefromstr(thedate){
	//15/3/2016
	// chrome have setMonth problem , so we use another way to set it
	var sTmp = thedate.split('/');
	if (sTmp.length!=3) return new Date();
	
	var theYear = Number(sTmp[2]);
	var theMonth = Number(sTmp[1])-1;
	var theDay = Number(sTmp[0]);
	
	var thedt = new Date(theYear,theMonth,theDay);
	thedt.setHours(0);
	thedt.setMinutes(0);
	thedt.setSeconds(0);
	
	//alert(thedate+','+theMonth+',====='+thedt)
	return thedt;
}
function getdatefromstr2(thedate, thetime)
{
	var sTmp = thedate.split('-');
	if (sTmp.length!=3) return new Date();
	
		
	var theYear = Number(sTmp[0]);
	var theMonth = Number(sTmp[1])-1;
	var theDay = Number(sTmp[2]);
	var thedt = new Date(theYear,theMonth,theDay);
	thedt.setHours(0);
	thedt.setMinutes(0);
	thedt.setSeconds(0);
	
	/*
	var thedt = new Date();
	var sTmp = thedate.split('-');
	if (sTmp.length!=3) return thedt;
	thedt.setFullYear(Number(sTmp[0]));
	thedt.setMonth(Number(sTmp[1])-1);
	thedt.setDate(Number(sTmp[2]));
	*/
	
	if (typeof(thetime)!='undefined')
	{
		sTmp = thetime.split(':');	
		thedt.setHours(Number(sTmp[0]));
		thedt.setMinutes(Number(sTmp[1]));
		if (sTmp.length>=3)
			thedt.setSeconds(Number(sTmp[2]));
		
	}
	return thedt;
}

String.prototype.trim = function () {
    return this.replace(/^\s*/, "").replace(/\s*$/, "");
};

function RunAppMode()
{
	if(typeof(AppMode)=='number')
	{
		try
		{

			switch(AppMode)
			{
				case 1:
					// Any class has WinCE name will hide
					$('.WinCE').each(function(){
					
						// add skip tag file in here...
					
						$(this).hide();
					});
				break;
				case 0:
				default:break;
			}
			
		}catch(e){alert('RunAppMode - '+ e.message);}
	}
}

function covert2minsec(ttl)
{
	if (ttl=='' || ttl == '0' || ttl == 0)
	{
		return "0";
	}
	
	var m, s, ret='';
	
	m = Math.floor(ttl/60);
	s = ttl-(m*60);
	
	if (m!=0)
		ret = m + ' min' + ' ';
		
	if (s!=0)
		ret =ret + s + ' sec';
	
	return ret;
}
function min2hourmin(ttl){
	if (ttl=='' || ttl == '0' || ttl == 0)
	{
		return "00:00";
	}
	var theHour = Math.floor(ttl / 60);
	var theMin = ttl % 60;
				
	return  Int2Str(theHour,2) +  ':'  + Int2Str(theMin,2);
}
function min2minsec(ttl)
{
	if (ttl=='' || ttl == '0' || ttl == 0)
	{
		return "00:00";
	}
	var date = new Date(null);
	date.setSeconds(ttl);
	
	if (date.toTimeString().length>=8)
	{
		return date.toTimeString().substr(3, 5);
	}
				
	return '00:00';
	/*
	var m, s, ret;
	
	m = Math.floor(ttl/60);
	s = (ttl-m)*60;
	if (m<10) ret = '0'+m;
	else ret = m;
	
	ret = ret + ':';
	
	if (s<10) ret = '0'+s;
	else ret = ret  + s;	*/
}

function divnodesstatus(id, stts)
{
	var nodes = document.getElementById(id).getElementsByTagName('*');
	for(var i = 0; i < nodes.length; i++)
	{
		nodes[i].disabled = stts;
	}
}

