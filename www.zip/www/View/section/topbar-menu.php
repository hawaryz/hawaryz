<nav id="topbar" class="navbar navbar-expand-md navbar-dark">
				<div class="container-fluid" style="display: block;">
					<div class="row">
			
					<div class="col-md-6 col-lg-6 col-xl-6 no-padding topbar-left">
						<ul class="navbar-nav">
							<li class="nav-item active">
								<a id="toggle-sidebar" class="nav-link" href="#">
									<i class="lnr lnr-menu"></i></a>
							</li>
							<li class="nav-item" id="page_title">
								<a class="nav-link" style="color:white;" id="thesumheaderlabel"></a>
							</li>

						</ul>
					</div>
					
					<div class="col-md-6 col-lg-6 col-xl-6 no-padding topbar-right">
						<!-- pushing two items to the left (ml-auto) -->
						<ul class="navbar-nav ml-auto">
							<li class="nav-item">
								<span class="welcome"><span id="lwlcm" style="font-weight:normal;font-style: italic;">Welcome</span>&nbsp;<span id="topusername">qbAdmin</span> !</span>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="">
									<i class="lnr lnr-user"></i>
								</a>
							</li>
							<!-- Alert -->
							<li class="nav-item">
								<a class="nav-link" onclick="openNav()">
									<i class="lnr lnr-alarm"></i>
									<span id="badgeNotifyMessage" class="badge badge-pill badge-bg notification">1</span>
								</a>
							</li>


							<!-- Divider -->
							<li class="dividerbar"></li>
							<li class="nav-item">
								<a class="nav-link" onclick="logoutuser()">
									<i class="lnr lnr-exit"></i>
								</a>
							</li>
							<!-- User -->
							<!--
							<li class=" nav-item dropdown">
								<a class="nav-link" href="#" id="navbardrop" data-toggle="dropdown">
									<i class="lnr lnr-user"></i>
								</a>
								<div class="dropdown dropdown-menu userPositonMenu">
									<div class="col-md-3 column">
										<ul class="header-menu main-menu">
											<li><a class="dropdown-item" href="#">My Profile</a></li>
											<li><a class="dropdown-item" href="#">Subscription</a></li>
											<li><a class="dropdown-item" href="#">Account</a></li>
											<li><a class="dropdown-item" href="#">Billing</a></li>
											<hr>
											<a class="dropdown-item" href="#" onclick="logoutuser()">Sign Out</a>
										</ul>
									</div>
								</div>
							</li>
							-->
						</ul>
					</div>
					</div>
				</div>
			</nav>