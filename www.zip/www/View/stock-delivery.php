<div class="row page-header">
		<div class="page-subtitle pagelist col-md-9 col-lg-9 col-xl-10 no-padding">
			<div class="page title font-weight-bold">Summary : Stock Delivery</div>
		</div>
		<div class="page-button col-md-3 col-lg-3 col-xl-2 no-padding">
			<div id="functionbuttonarea" class="pull-right">
        <center>
        <button id="btnAdd" type="button" class="btn btn-orange" style="background-color: #FF8C00; color: #fff; border-radius:20px;" onclick="AddNewItem()"><span>Create</span></button>
        </center>
      </div>
		</div>
	</div>
<div class="row">
  <div class="col-md-12 pb-3">
    <ul class="border-bottom"></ul>
  </div>
</div>

<div id="stockdeliveryTblArea">

</div>

<script src="js/stock-delivery.js"> </script>