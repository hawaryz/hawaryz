BuildTable('stockdeliveryTbl',[`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`],`stockdeliveryTblArea`);
  var table_2 = DatatableInitialize('stockdeliveryTbl');
  DatatableAppendBody(table_2,[[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ],[
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
      '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
  ]],0);