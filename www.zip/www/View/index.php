<html>
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=12; IE=11; IE=10; IE=9; IE=EDGE" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- DONT SAVE CACHE -->
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <!-- DONT SAVE CACHE -->
    <link href="plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet" />
    <link href="css/general.css" rel="stylesheet" />
    <link href="css/boostrap.min.css" rel="stylesheet" />
    <link href="css/all.css" rel="stylesheet" />
    <link href="css/jquery.mCustomScrollbar.min.css" rel="stylesheet" />
    <link href="css/linearicons.css" rel="stylesheet" />
    <link href="css/boostrap-datetimepicker.css" rel="stylesheet" />
    <link href="css/dataTables.boostrap4.min.css" rel="stylesheet" />
    <link href="css/main.css" rel="stylesheet" />
    <link href="css/sidebar-themes.css" rel="stylesheet" />
    <link href="css/bootstrap-select.css" rel="stylesheet" />
	<link href="css/custom.css" rel="stylesheet" />
    <title>QB10 Capitaland</title>
    <!-- ADDITION PLUGIN --> 
	<?php include_once '../Gateway/Public-Access/Pre-Load-Additional-Js-Scripting.php';?>
    <!-- ADDITION PLUGIN -->
  </head>
  <body onload="sidebarMenuNav()">
    <div class="page-wrapper light-theme sidebar-bg bg1 toggled">
    
	<!-- SIDEBAR MENU --> 
	<?php include_once 'section/sidebar-menu.php';?>
	<!-- SIDEBAR MENU -->

      <main class="page-content">
        <div id="overlay" class="overlay"></div>
        
        <!-- SIDEBAR MENU --> 
        <?php include_once 'section/topbar-menu.php';?>
        <!-- SIDEBAR MENU -->

        <div id="ajax-content" class="container-fluid bg-pd">
          
        <div id="top-menu" class="row main-menu no-padding">
          <ul>
            <li class="linkOption">
              <a onclick="topbarMenuNav(this)" id="ManageShippingBtnId">Manage Shipping</a>
            </li>
            <li class="linkOption">
              <a onclick="topbarMenuNav(this)" id="ManageModelBtnId">Manage Model</a>
            </li>
            <li class="linkOption">
              <a onclick="topbarMenuNav(this)" id="ManageWarrantyBtnId">Manage Warranty</a>
            </li>
            <li class="linkOption">
              <a onclick="topbarMenuNav(this)" id="ManageSupplierSNBtnId">Manage Supplier SN</a>
            </li>
            <li class="linkOption">
              <a onclick="topbarMenuNav(this)" id="ManageSoftwareBtnId">Manage Software</a>
            </li>
            <li class="linkOption">
              <a onclick="topbarMenuNav(this)" id="ManageSupplierBtnId">Manage Supplier</a>
            </li>
          </ul>
        </div>
		  <div id="main-content">
			Loading.....
		  </div>

        </div>
        
  </body>
  <!-- ADDITION PLUGIN --> 
  <?php include_once '../Gateway/Public-Access/Post-Load-Additional-Js-Scripting.php';?>
  <!-- ADDITION PLUGIN -->
  <script src="js/view_controller.js"></script>
  
</html>