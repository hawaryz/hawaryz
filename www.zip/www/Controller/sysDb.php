<?php
include_once "sysJson.php";
include_once "sysDbPopUp.php";
include_once "../Config/sysConfig.php";


if (!class_exists('SQLite3')) {
    include_once "sysByPassSQLITE.php";
}


function runSQL($SQL,$UniqProcessName) {
    $ProcessSQL = new ProcessSQL();
    $json = $ProcessSQL->Execute($SQL,$UniqProcessName);
    return $json;
}


class DatabaseModel extends SQLite3 {

    private $dbfileName = "../Database/database.db";

    function __construct(){
        return $this->open($this->dbfileName);
    }
}

class ProcessSQL {

    private $db;
    private $SQL;

    function Execute($SQL,$UniqProcessName){
        $SQL_ = explode("|||", $SQL)[1];
        $RESERVE_WORD = explode("|||", $SQL)[0];
        $isDebugMode = isDebugMode();
        if (getDatabaseType()['dbType'] == "phpMyAdmin") {
            $servername = getDatabaseType()['servername'];
            $username = getDatabaseType()['username'];
            $password = getDatabaseType()['password'];
            $dbname = getDatabaseType()['dbname'];

            // if (strpos($SQL_, "FROM")) {
            if ($RESERVE_WORD != "_NO_NEED_RETURN_DATA_") {
                try {
                    $dbs = new PDO('mysql:host='.$servername.'; dbname='.$dbname, $username, $password);
                    $dbs->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $query = $dbs->prepare($SQL_);
                    $query->bindParam(":id_val", $id);
                    $query->execute();
                    $results = $query->fetchAll(PDO::FETCH_ASSOC);
                    if ($results) {
                        $_temp = "";
                        foreach ($results as $_results) {
                            $_temp .= json_encode($_results).",";
                        }
                        $json = new BuildJSON($_temp);
                        return $json->format();
                    }
                    $dbs = null;
                } catch (Exception $e) {
                    if ($isDebugMode) {
                        $e = preg_replace('/[^A-Za-z0-9 ]/', '', $e);
                        showDebugPopUp("$e");
                    } else {
                        showDbPopUp("[".$UniqProcessName."]",0);
                    }
                }
            } else {
                try {
                    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
                    // set the PDO error mode to exception
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $conn->exec($SQL_);
                    showDbPopUp("Operation Success",1);
                    return "";
                  } catch(PDOException $e) {
                    if ($isDebugMode) {
                        $e = preg_replace('/[^A-Za-z0-9 ]/', '', $e);
                        showDebugPopUp("$e");
                    } else {
                        showDbPopUp("[".$UniqProcessName."]",0);
                    }
                  }
                  $conn = null;
            }



            
        } 











        else if (getDatabaseType()['dbType'] == "SQllite"){
            $this->db = new DatabaseModel();
            $this->SQL = $SQL_;
            // if (strpos($SQL_, "FROM")) {
            if ($RESERVE_WORD != "_NO_NEED_RETURN_DATA_") {
                try {
                    $_temp = "";
                    $sql_ = $this->SQL;
                    $this->db->enableExceptions(true);
                    $data = $this->db->query($sql_);
                    while($row = $data->fetchArray(SQLITE3_ASSOC) ) {
                        $_temp .= json_encode($row).",";
                    }
                    $json = new BuildJSON($_temp);
                    return $json->format();
                } catch (Exception $e) {
                    if ($isDebugMode) {
                        $e = preg_replace('/[^A-Za-z0-9 ]/', '', $e);
                        showDebugPopUp("$e");
                    } else {
                        showDbPopUp("[".$UniqProcessName."]",0);
                    }
                }
            } else {
                try {
                    $sql = $this->SQL;
                    $this->db->enableExceptions(true);
                    $this->db->exec($sql);
                    showDbPopUp("Operation Success",1);
                    return "<script>unloadLoaderSpinner();</script>";
                } catch (Exception $e) {
                    if ($isDebugMode) {
                        $e = preg_replace('/[^A-Za-z0-9 ]/', '', $e);
                        showDebugPopUp("$e");
                    } else {
                        showDbPopUp("[".$UniqProcessName."]",0);
                    }
                }
            }
        }

        
        
    }

}






?>