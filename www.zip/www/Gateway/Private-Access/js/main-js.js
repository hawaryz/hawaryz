var insertDataUrl = window.location.href.split("/View/")[0]+'/Model/sysInsert.php';
var getDataUrl = window.location.href.split("/View/")[0]+'/Model/sysGet.php';
var updateDataUrl = window.location.href.split("/View/")[0]+'/Model/sysUpdate.php';
var deleteDataUrl = window.location.href.split("/View/")[0]+'/Model/sysDelete.php';




























// ------------------------------------------------------------------------------------- //
// THIS TWO FUNCTION USE TO BUILD DATATABLE AND APPEND THE DATATABLE BODY DATA
// FIRST CREATE THE DATATABLE
// SECOND PASS THE DATATABLE ID TO FUNCTION APPEN ROW WITH ARRAY OF BODY DATA TO ADD
// EG:
/*
BuildTable('example',[`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`,`<th class="name">Name</th>`],`datatableArea`);
var table_1 = DatatableInitialize('example');
DatatableAppendBody(table_1,[[
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
],[
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>',
    '<td><input type="text" value="Tiger Nixon" onblur="YourFunctionName()"></td>'
]],0);*/

function BuildTable(tbl_id,THeaderColumnsPerRow,pointAreaId){
    var Temp = `<table id="`+tbl_id+`" class="table table-striped table-bordered inline-editable-datatable" cellspacing="0" width="100%"> <thead> <tr>`;
    for (var thead = 0; thead < THeaderColumnsPerRow.length; thead++) { Temp += THeaderColumnsPerRow[thead]; }
    Temp += `</tr></thead></table>`;
    $('#'+pointAreaId).html(Temp);
}

function DatatableInitialize(tbl_id){
    var table_id = $('#'+tbl_id).DataTable( {
        "pageLength": 10,
        "order": [[ 0, "desc" ]],
        "columnDefs": [
            {
                "visible": false,
                "searchable": true
            }
        ],
      } );
      return table_id;
}

function DatatableAppendBody(datatableObject,TBodyColumnsPerRow, isClearBeforeAddRow){
    if (isClearBeforeAddRow == 1) { datatableObject.clear().draw(); }
    for (var rows = 0; rows < TBodyColumnsPerRow.length; rows++) {
        datatableObject.row.add( TBodyColumnsPerRow[rows] ).draw( false );
    }
}
// ------------------------------------------------------------------------------------- //


// ------------------------------------------------------------------------------------- //
// THIS FUNCTION USE TO CATCH ERROR SYNTAX OF FUNCTION CALL
// USAGE EXAMPLE :: catcher({id1: "100"}, somefunctionname);
// EG : 
/*
function exampleErrorCode(id) {
    alert(ids['id1']);
}
catcher({id1: "100"}, exampleErrorCode);
*/
function catcher(argument, functionToCatch) {
    try {
        functionToCatch(argument);
    } catch(err) {
        $( "#jsErrorCode_text" ).html( err+"\n\n"+functionToCatch );
        $( "#jsErrorCode" ).dialog();
    }
}
// ------------------------------------------------------------------------------------- //

// ------------------------------------------------------------------------------------- //
// THIS FUNCTION USE TO CREATE INPUT
// E.G :
/* 
buildElementInput('asd','selectClass','number','somevalue','somePlaceholder','elementInputArea');
*/
function buildElementInput(selectId,selectClass,type,value,placeholder,pointAreaId){
    $('#'+pointAreaId).html("<input id='"+selectId+"' class='"+selectClass+"' type='"+type+"' value='"+value+"' placeholder='"+placeholder+"' />");
}
// ------------------------------------------------------------------------------------- //

// ------------------------------------------------------------------------------------- //
// THIS FUNCTION USE TO CREATE SELECT(DROPDOWN BOX)
// EG :
/*
var arr = [{value: 100, display_value: 200},{value: 100, display_value: 200}];
buildElementSelect("someId","SomeClass",arr,"elementSelectTest");
*/

function buildElementSelect(selectId,selectClass,arrData,pointAreaId) {
    var optionLength = arrData.length;
    var _Temp = "<select id="+selectId+" class='"+selectClass+"'>";
    
    for (var option = 0; option < optionLength; option++) {
        _Temp += "<option value='"+arrData[option]['value']+"'>"+arrData[option]['display_value']+"</option>";
    }

    _Temp += "</select>";
    $('#'+pointAreaId).html(_Temp);
}
// ------------------------------------------------------------------------------------- //

// ------------------------------------------------------------------------------------- //
// THIS FUNCTION USE TO INSERT DATA TO SERVER
// EG :
/*
    // var jsonReturn = InsertCGI_Array(insertDataUrl,"tblname=Car_list",{"car_plate":"cvbnnnn"});
    // $('#AlertPoint').html(jsonReturn);
*/
function InsertCGI_Array(CGIurl,getParamInString, paramArrayKey) {

    var getParam = "";
    for ( var _paramArrayKey in paramArrayKey ) {
        // console.log( _paramArrayKey );
        // console.log( paramArrayKey[_paramArrayKey] );
        getParam += "&"+_paramArrayKey+"="+paramArrayKey[_paramArrayKey];
      }
    var generatedUrl = CGIurl+"?"+getParamInString+getParam;
    console.log(generatedUrl);
    cgiGetSync(generatedUrl);
    ChkComSyncEx();
    return _retmsgEx;
}
// ------------------------------------------------------------------------------------- //

// ------------------------------------------------------------------------------------- //
// THIS FUNCTION USE TO INSERT DATA TO SERVER
// EG :
/*
    // var jsonReturn = InsertCGI_SQL(insertDataUrl,"SQL=INSERT INTO `Car_list` (`car_plate`) VALUES( 'TGV');");
    // $('#AlertPoint').html(jsonReturn);
*/
function InsertCGI_SQL(CGIurl,getParamInString) {
    var generatedUrl = CGIurl+"?"+getParamInString;
    console.log(generatedUrl);
    cgiGetSync(generatedUrl);
    ChkComSyncEx();
    return _retmsgEx;
}
// ------------------------------------------------------------------------------------- //

// ------------------------------------------------------------------------------------- //
// THIS FUNCTION USE TO DELETE DATA FROM SERVER
// EG :
/*
    // var jsonReturn = DeleteCGI_SQL(deleteDataUrl,"SQL=DELETE FROM `Car_list` WHERE `car_id` = '1037';");
    // $('#AlertPoint').html(jsonReturn);
*/
function DeleteCGI_SQL(CGIurl,getParamInString) {
    var generatedUrl = CGIurl+"?"+getParamInString;
    console.log(generatedUrl);
    cgiGetSync(generatedUrl);
    ChkComSyncEx();
    return _retmsgEx;
}
// ------------------------------------------------------------------------------------- //

// ------------------------------------------------------------------------------------- //
// THIS FUNCTION USE TO GET DATA FROM SERVER
// EG :
/*
    // var jsonReturn = GetCGI_SQL(getDataUrl,"SQL=SELECT * FROM `Car_list`");
    // $('#AlertPoint').html(jsonReturn);
*/
function GetCGI_SQL(CGIurl,getParamInString) {
    var generatedUrl = CGIurl+"?"+getParamInString;
    console.log(generatedUrl);
    cgiGetSync(generatedUrl);
    ChkComSyncEx();
    return _retmsgEx;
}
// ------------------------------------------------------------------------------------- //

// ------------------------------------------------------------------------------------- //
// THIS FUNCTION USE TO UPDATE DATA TO SERVER
// EG :
/*
    // var jsonReturn = UpdateCGI_SQL(updateDataUrl,"SQL=UPDATE `Car_list` SET `car_plate` = 'cvbnnnn' WHERE `car_id` = '321';");
    // $('#AlertPoint').html(jsonReturn);
*/
function UpdateCGI_SQL(CGIurl,getParamInString) {
    var generatedUrl = CGIurl+"?"+getParamInString;
    console.log(generatedUrl);
    cgiGetSync(generatedUrl);
    ChkComSyncEx();
    return _retmsgEx;
}
// ------------------------------------------------------------------------------------- //

// ------------------------------------------------------------------------------------- //
// THIS FUNCTION STILL UNDER DEVELOPMENT...!!!
// loadLoaderSpinner();
// unloadLoaderSpinner(); 

function loadLoaderSpinner() {
  $("#loaderSpinner").modal({
    backdrop: "static", //remove ability to close modal with click
    keyboard: false, //remove option to close with keyboard
    show: true //Display loader!
  });
}

function unloadLoaderSpinner() {
    $("#loaderSpinner").modal("hide");
}
// ------------------------------------------------------------------------------------- //

// ------------------------------------------------------------------------------------- //
// THIS FUNCTION USE LOAD CONTENT FOR WHICH DIV
// EG :
/*
    loadContent("pointAreaId","content.html");
*/

function loadContent(pointAreaId,contentToCall){
    $("#"+pointAreaId).load(contentToCall);
}
// ------------------------------------------------------------------------------------- //