<?php
// phpinfo();
// $out = shell_exec("powershell.exe Get-Counter -Counter '\Processor(_Total)\% Processor Time'");
// $out = shell_exec("powershell.exe Clear-RecycleBin -Force");
// $out = shell_exec("powershell.exe get-wmiobject -class win32_quickfixengineering");
// $out = shell_exec("powershell.exe Get-WmiObject win32_VideoController");
// $out = shell_exec("powershell.exe Get-WmiObject Win32_PnPSignedDriver");
// $out = shell_exec("powershell.exe Get-NetAdapter | Select interfaceDescription, name, status, linkSpeed");
// echo '<pre>'.$out.'</pre>';
?>
<script type="text/javascript">

// Redirect
location.replace("View/index.php");
// location.replace("Controller/sysSQLBuilder.php?tblname=models&models_id=1&models_name=hawari&models_itemname=polis");
// Redirect

</script>





