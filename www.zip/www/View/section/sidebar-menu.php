




    <nav id="sidebar" class="sidebar-wrapper">
            <div class="sidebar-content">
                <!-- sidebar-brand -->
                <div class="sidebar-item sidebar-brand logo">
                  <a href="#"><img src="images/logo_queuebee.png"></a></div>
                  <!-- sidebar-menu -->
                <div class="sidebar-item sidebar-menu">
                    <ul class="nav nav-side-menu">
                    <li>
              <a class="ajax-link ltr" style="color: #fff">
                <i class="lnr lnr-pie-chart"></i>
                <span class="menu-text " id="dashboardBtnId" onclick="sidebarMenuNav(this)">Dashboard</span>
              </a>
            </li>
                    <li>
              <a class="ajax-link ltr" style="color: #fff">
                <i class="lnr lnr-pie-chart"></i>
                <span class="menu-text" id="stockinBtnId" onclick="sidebarMenuNav(this)">Stock In</span>
              </a>
            </li>
            <li>
              <a class="ajax-link ltr" style="color: #fff">
                <i class="lnr lnr-pie-chart"></i>
                <span class="menu-text" id="stockqcBtnId" onclick="sidebarMenuNav(this)">Stock QC</span>
              </a>
            </li>
            <li>
              <a class="ajax-link ltr" style="color: #fff">
                <i class="lnr lnr-pie-chart"></i>
                <span class="menu-text" id="stockoutBtnId" onclick="sidebarMenuNav(this)">Stock Out</span>
              </a>
            </li>
            <li>
              <a class="ajax-link ltr" style="color: #fff">
                <i class="lnr lnr-pie-chart"></i>
                <span class="menu-text" id="deliveryBtnId" onclick="sidebarMenuNav(this)">Stock Delivery</span>
              </a>
            </li>
						<li class="menu-border-top bottom">
							<!--SettingMenu-->
							<button onclick="openSetPopupMenu()" class="dropdown-btn" style="color: #fff;"> 
								<i class="lnr lnr-cog"></i>
									<span class="menu-text" id="lset">Setting</span> 
							</button>
							 <div class="dropdown-container hide" id="extendedSetMenu" style="display: none;" onclick="$(this).hide();">
								<ul>
									<li>
										<a href="#feedback">
											<i class="lnr lnr-thumbs-up"></i>
											<span class="menu-text" id="lqos">Customer Feedback</span>
										</a>
									</li>
									<li>
										<a href="#support">
											<i class="lnr lnr-license"></i>
											<span class="menu-text" id="">Ticket support</span>
										</a>
									</li>
									<li class="menu-border-top">
										<a href="#advset">
											<i class="lnr lnr-diamond"></i>
											<span class="menu-text" id="ladvset">Advance Setting</span>
										</a>
									</li>
									<li>
										<a href="#device">
											<i class="lnr lnr-laptop-phone"></i>
											<span class="menu-text" id="ldev">Hardware Devices</span>
										</a>
									</li>
									<li>
										<a href="#adminctl">
											<i class="lnr lnr-users"></i>
											<span class="menu-text" id="lppl">People Management</span>
										</a>
									</li>
									<li>
										<a href="#mntnc">
											<i class="lnr lnr-construction"></i>
											<span class="menu-text" id="lmntnc">Maintenance</span>
										</a>
									</li>
									<li>
										<a href="#alert">
											<i class="lnr lnr-warning"></i>
											<span class="menu-text" id="lalrmsg">Notifications</span>
										</a>
									</li>
									<span class="arrow-right"></span>
								</ul>
							 </div>
                        </li>
                    </ul>
                </div><!-- sidebar-menu -->
            </div>
        </nav>