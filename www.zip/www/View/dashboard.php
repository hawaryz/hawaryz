<h4 style="font-weight:bold;">this is dashboard content...</h4>
<div class="row">
  <div class="col-md-12 pb-3">
    <ul class="border-bottom"></ul>
  </div>
</div>

<div class="container-rptSetting mb-3">
					<div class="row">
						<div class="col-md-6" style="border-right:1px solid #ced4da">
							<div style="font-weight:bolder">Date and Duration</div>
							<div class="row">
                                
							</div>
						</div>
						<div class="col-md-6">
							<div style="font-weight:bolder">Date and Duration</div>
							<div class="row">
                                
							</div>
						</div>
					</div>
				</div>
                