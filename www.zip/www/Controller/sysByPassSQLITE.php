<?php
class SQLite3 {}
?>